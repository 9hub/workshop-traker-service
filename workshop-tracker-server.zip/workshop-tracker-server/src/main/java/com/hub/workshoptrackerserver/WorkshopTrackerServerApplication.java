package com.hub.workshoptrackerserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkshopTrackerServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkshopTrackerServerApplication.class, args);
	}

}
